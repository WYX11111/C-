// AutoLirary.h: interface for the AutoLirary class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_AUTOLIRARY_H__806280E7_0E34_453C_A1A3_ED6709452D1F__INCLUDED_)
#define AFX_AUTOLIRARY_H__806280E7_0E34_453C_A1A3_ED6709452D1F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class AutoLirary  
{
public:
	//bool cmpIgnoreCase(char c1, char c2);
	AutoLirary();
	virtual ~AutoLirary();

};

#endif // !defined(AFX_AUTOLIRARY_H__806280E7_0E34_453C_A1A3_ED6709452D1F__INCLUDED_)
